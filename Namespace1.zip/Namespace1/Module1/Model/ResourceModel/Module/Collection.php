<?php

/**
 * <Module> Resource Collection
 */
namespace <Namespace>\<Module>\Model\ResourceModel\<Module>;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('<Namespace>\<Module>\Model\<Module>', '<Namespace>\<Module>\Model\ResourceModel\<Module>');
    }
}
