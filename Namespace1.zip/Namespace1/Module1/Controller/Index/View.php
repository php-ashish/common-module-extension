<?php

namespace <Namespace>\<Module>\Controller\Index;

use <Namespace>\<Module>\Controller\<Module>Interface;

class View extends \<Namespace>\<Module>\Controller\AbstractController\View implements <Module>Interface
{

}
